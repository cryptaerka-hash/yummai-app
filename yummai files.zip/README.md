# 🍽️ YummAI — Smart Restaurant Platform

> **Самая технологичная ресторанная платформа Центральной Азии**

[![Demo](https://img.shields.io/badge/Live%20Demo-yummai.app-FF6B2B?style=for-the-badge)](https://cryptaerka-hash.github.io/yummai-app/)
[![Status](https://img.shields.io/badge/Status-MVP%20Prototype-green?style=for-the-badge)]()
[![Market](https://img.shields.io/badge/Market-Uzbekistan%20%7C%20Central%20Asia-blue?style=for-the-badge)]()

---

## Что это

YummAI — SaaS-платформа для автоматизации ресторанов. QR-меню, AI-апселл, кухонный дисплей и бизнес-аналитика в одном продукте. Первый AI-powered ресторанный сервис в Узбекистане.

**Средний чек ресторана растёт на +23% с первого месяца** — AI сам предлагает дополнения к заказу без участия официанта.

---

## Проблема

Рестораны в Узбекистане работают вслепую:

| Проблема | Масштаб |
|---|---|
| Гость ждёт официанта 10-15 минут | Каждый стол каждый день |
| Официанты не апселлят | -20-30% к потенциальному чеку |
| Бумажное меню: изменил цену → типография | 3-7 дней задержки |
| Хаос на кухне: бумага + крик | Ошибки в 15% заказов |
| Нет аналитики | Решения на интуиции, не на данных |
| "Терминал сломан" | Потеря клиентов без кэша |

---

## Решение

```
Гость сканирует QR → выбирает блюдо → AI предлагает дополнения
→ заказ летит на кухонный дисплей → оплата Click/Payme
→ владелец видит аналитику в реальном времени
```

### Модули MVP

- **📱 QR-меню** — PWA без установки, фото, категории, модификаторы
- **🤖 AI Upsell Engine** — рекомендации по ассоциативным правилам + ML
- **🔔 Kitchen Display System** — WebSocket real-time, статусы NEW→COOKING→READY
- **💳 Click / Payme** — нативная оплата в UZS без терминала
- **📊 Аналитика** — выручка, средний чек, топ-блюда, AI-инсайты
- **⚙️ Панель владельца** — меню, цены, акции, столы в реальном времени
- **🔗 R-Keeper интеграция** — JSON-RPC bridge для существующих касс

---

## Технический стек

```
Backend:    NestJS + TypeScript
Database:   PostgreSQL + Prisma ORM
Cache:      Redis (pub/sub для real-time)
Frontend:   React + Tailwind CSS + Zustand
Real-time:  Socket.IO (WebSocket)
PWA:        Workbox + IndexedDB (offline-first)
Payments:   Click API + Payme API
SMS:        Eskiz.uz / Playmobile
AI:         GPT-4 API + Association Rules Engine
Infra:      Docker + CI/CD
```

---

## Бизнес-модель

| Тариф | Цена/месяц | Для кого |
|---|---|---|
| Старт | 1 500 000 UZS (~$120) | 1-2 точки |
| Бизнес | 2 000 000 UZS (~$160) | До 5 точек + AI |
| Сеть | 2 500 000 UZS (~$200) | Неограничено + White Label |

**Target Year 1:** 50 ресторанов → 75M–125M UZS/месяц MRR

Окупаемость для клиента: **1 месяц** (рост чека +23% перекрывает стоимость подписки)

---

## Конкурентное окно

- **iiko / R-Keeper** — дорого, сложно, нет AI, нет Click/Payme
- **Toast / Square** — не работают в СНГ
- **Местные решения** — не существуют
- **YummAI** — первый, локальный, с AI, с нативными платежами

---

## Прототип

Живой интерактивный прототип: [**cryptaerka-hash.github.io/yummai-app**](https://cryptaerka-hash.github.io/yummai-app/)

Включает:
- Экран гостя (QR-меню, корзина, AI-апселл)
- Kitchen Display System (живые статусы заказов)
- Аналитика владельца (выручка, топ-блюда)
- Scope of Work для команды разработки

---

## Roadmap

```
Q1 2025  ─── MVP: QR-меню + заказ + KDS + Click/Payme
Q2 2025  ─── AI Upsell Engine + Аналитика
Q3 2025  ─── R-Keeper интеграция + Мульти-точка
Q4 2025  ─── Казахстан + Кыргызстан + White Label
2026     ─── Таджикистан + Туркменистан + API платформа
```

---

## Основатель

**Erka Maratov** — Co-founder FLY TAXI (ridesharing, Nukus, 4+ years)  
CS degree, TATU Nukus branch  
Building: YummAI + SPOT (transport platform, Central Asia)

📍 Nukus, Karakalpakstan, Uzbekistan  
🐙 GitHub: [@cryptaerka-hash](https://github.com/cryptaerka-hash)

---

*YummAI — Built in Nukus, for Central Asia, world-class level.*
